from django.db import models
from django.contrib.auth.models import User

from django.urls import reverse

from django.contrib.auth.models import User
from PIL import Image
from django.utils.text import slugify
from ckeditor.fields import RichTextField


# Extending User Model Using a One-To-One Link
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    image = models.ImageField(default='default.png', upload_to='profile_images')
    
    def __str__(self):
        return self.user.username
'''
    # resizing images
    def save(self, *args, **kwargs):
        super().save()

        img = Image.open(self.image.path)

        if img.height > 100 or img.width > 100:
            new_img = (100, 100)
            img.thumbnail(new_img)
            img.save(self.image.path)

'''



def image_upload(instance,filename):
    imagename , extension = filename.split(".")
    return "photo/%s.%s"%(instance.id,extension)

Pages_TYPE = (
        ('الصفحة الرئيسية','الصفحة الرئيسية'),
        ('من نحن','من نحن'),
        ('اتصل بنا','اتصل بنا'),
    )

class Pages(models.Model):  
    name = models.CharField(max_length=60,choices=Pages_TYPE)
    sub_heading = models.CharField(max_length=100)
    image = models.ImageField(upload_to=image_upload, null=True, blank=True)
    image2 = models.ImageField(upload_to=image_upload, null=True, blank=True)
    image3 = models.ImageField(upload_to=image_upload, null=True, blank=True)
    pubilished_at = models.DateTimeField(auto_now=True)
    description = RichTextField(null=False, blank=False)

    slug = models.SlugField(max_length=60,unique=True, blank=True, null=True)

    def save(self,*args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name, allow_unicode=True)
        super(Pages, self).save(*args, **kwargs)

    def __str__(self):
        return self.name




class Category(models.Model):
    #, allow_unicode=True
    category_name  = models.CharField(max_length=60)
    image = models.ImageField(upload_to=image_upload, null=False, blank=False)
    price = models.IntegerField()
    description = RichTextField(null=False, blank=False)
    create_at = models.DateTimeField(auto_now=True)

    slug = models.SlugField(max_length=60,unique=True, blank=True, null=True)

    def save(self,*args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.category_name, allow_unicode=True)
        super(Category, self).save(*args, **kwargs)

   

   
    def __str__(self):
        return self.category_name




class Image(models.Model):

    description = models.CharField(max_length=60,null=True, blank=True)
    image = models.ImageField(upload_to=image_upload)
    category = models.ForeignKey('Category', on_delete=models.CASCADE, related_name='category')
    create_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.description


    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url





class InformaionSite(models.Model):
    name = models.CharField(max_length=60 , default='name')
    name_site = models.CharField(max_length=60,null=True, blank=True)
    image = models.ImageField(upload_to=image_upload, null=True, blank=True)

    address = models.CharField(max_length=60)
    email = models.EmailField(null=True, blank=True)
    telephone = models.IntegerField(null=True, blank=True)
    fax = models.IntegerField(null=True, blank=True)
    
    facebook = models.URLField(null=True, blank=True)
    twitter = models.URLField(null=True, blank=True)
    instagram = models.URLField(null=True, blank=True)
    whatsapp = models.URLField(null=True, blank=True)

    pubilished_at = models.DateTimeField(auto_now=True)
    description = RichTextField(null=False, blank=False)
    
    contact = RichTextField(null=False, blank=False)


    
