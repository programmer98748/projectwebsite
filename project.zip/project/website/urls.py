
from django.urls import path, include
from . import views
from django.urls import path, re_path

urlpatterns = [
    #re_path(r'^blog/(?P<slug>[^/]+)/?$', views.category_project, name='category_project'),

    path('', views.home, name="index"),
    path('contact/', views.contact, name="contact"),
    path('about/', views.about, name="about"),

    path('product/<str:slug>/', views.products, name="products"),
    path('projucts/', views.projucts, name="projects"),


   
]
