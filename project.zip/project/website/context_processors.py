from dashboard.models import Category,Pages, Image, User, InformaionSite

def navbar_categories(request):
   
    categories = Category.objects.all()

    information_site = InformaionSite.objects.all()


    return {'navbar_categories':categories,'information_site':information_site}
