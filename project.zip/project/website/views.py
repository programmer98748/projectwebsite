from django.shortcuts import render
from django.db.models import Prefetch

from django.utils.text import slugify


# Create your views here.
from dashboard.models import Category, Pages, Image, User, InformaionSite

from .models import *
from django.core.mail import send_mail
from django.conf import settings
 
def home(request):
    category = Category.objects.prefetch_related('category').all() 

    category__sidbar = Category.objects.all()
    imges = Image.objects.all()[:3]
    context = {
        'home':home,
        'categories':category,
        'category__sidbar':category__sidbar,
        'imges':imges,
    }

    return render(request, 'web/pages/home.html', context) 

def products(request, slug):
    
    if(Category.objects.filter(slug=slug)):
        image = Image.objects.filter(category__slug=slug)
        category = Category.objects.filter(slug=slug).first()

        images_count = Image.objects.filter(category__slug=slug).count()


        category_name = category.category_name 
        slug = slugify(category_name, allow_unicode=True)
        context = { 
            'category':category,
            'images':image,
            'images_count':images_count,
            }

        return render(request, 'web/pages/product.html', context) 




def about(request):
    about = Pages.objects.filter(name='من نحن')
    context = {  
        'about':about,  

    }
    return render(request, 'web/pages/about.html', context) 



def contact(request):
    contact = Pages.objects.filter(name='اتصل بنا')

    if request.method == 'POST':
        name = request.POST['name']
        phone = request.POST['phone']
        subject = request.POST['subject']
        email = request.POST['email']
        message = request.POST['message']

        send_mail(
            subject,
            message,
            email,
            [settings.EMAIL_HOST_USER],
        )

    context = {
        'contact':contact  
    }
    return render(request, 'web/pages/contact.html', context) 




def projucts(request):
    category = Category.objects.all()
    context = {  
        'category':category,  

    }
    return render(request, 'web/pages/projects.html', context) 




from django.shortcuts import render

def handel404(request, exception):
    return render(request, 'users/404.html', status=404)


def handel500(request):
    return render(request, 'users/500.html', status=500)